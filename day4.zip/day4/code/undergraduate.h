#pragma once

#include <iostream>
#include "student.h"

class undergraduate : public student
{
public:
    void showName()
    {
        cout << "我的名字是：" << getName() << endl;
    }
};