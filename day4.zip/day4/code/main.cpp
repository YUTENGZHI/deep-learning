#include <iostream>
#include "student.h"
#include "sort.hpp"
#include "math.hpp"
#include "undergraduate.h"

using namespace std;
using std::cout;


int g1 = 3;


void show()
{
    cout << "hello global" << std::endl;
}


namespace abc  // 定义命名空间 abc
{
    int g1 = 1;

    void show()
    {
        cout << "hello abc" << endl;
    }

    void write()
    {
        ;
    }
}


namespace def  // 定义命名空间 def
{
    int g1 = 2;

    void show()
    {
        cout << "hello def" << endl;
    }

    float g2 = 3.14;

    class person
    {
    private:
        int sno;

    public:
        void setSno(int sno)
        {
            this->sno = sno;
        }
    };
}


using namespace def;  // 将 def 命名空间设置为默认命名空间
using abc::write;


int main()
{
    undergraduate s2;

    undergraduate::f();

    s2.setName("李四");
    s2.show();
    s2.showName();
    
    /*
    // 通过类名访问静态成员
    student::f();
    student::count = 3;
    */

    /*
    int g1 = 4;

    cout << g1 << endl;  // 4  按照“就近原则“，这里访问的是局部变量 g1

    cout << abc::g1 << endl;  // 1
    cout << def::g1 << endl;  // 2
    cout << ::g1 << endl;     // 3 访问来自全局命名空间中 g1 变量

    ::show();
    abc::show();
    def::show();

    cout << g2 << endl;
    cout << def::g2 << endl;

    person s1;

    write();
    */

    // student s1(1001, "张三");

    // s1.show();

    // s1.setName("张三风");

    // s1.show();

    // student::sno_t i = 1003;

    // student::book b1 = {33333, 35.50};

    // student::sex s = student::male;

    // int a1[] = {5, 3, 4, 1, 2};
    // sort(a1, 5);

    // for(int i = 0; i < 5; i++)
    // {
    //     cout << a1[i] << ' ';
    // }

    // cout << endl;

    // char a2[] = "bagdcfe";
    // sort(a2, 7);
    // cout << a2 << endl;

    // double a3[] = {3.14, -5.9, 1.26, 0.5};
    // //sort(a3, 4);
    // sort<double>(a3, 4);  // 更明确的写法
    // for(int i = 0; i < 4; i++)
    // {
    //     cout << a3[i] << ' ';
    // }

    // math<int> m1(3, 5);
    // cout << m1.add() << endl;
    // cout << m1.max() << endl;

    // math<double> m2(3.5, 4.1);
    // cout << m2.add() << endl;

    // math<char> m3('a', 'b');

    return 0;
}