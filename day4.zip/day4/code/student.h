#pragma once

#include <string>

using namespace std;


class student
{
public:
    // 类型成员
    typedef unsigned int sno_t;

    struct book
    {
        int isbn;
        float price;
    };

    enum sex
    {
        male,
        female
    };

    static int count;  // 静态属性，必须在类外进行初始化

    static void f();   // 静态方法


private:
    sno_t sno;
    string name;
    sex s;
    
public:
    student();
    student(int sno, string name);
    ~student();

    string getName() const;
    void setName(const char* name);

    void show() const;
};


