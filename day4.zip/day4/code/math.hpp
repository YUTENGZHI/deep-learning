// 类模板

template < typename T>
class math
{
private:
    T a;
    T b;

public:
    math(T a, T b);
    T add();
    T max();
};


template < typename T>
math<T>::math(T a, T b):a(a), b(b)
{
}


template < typename T>
T math<T>::add()
{
    return a + b;
}


template < typename T>
T math<T>::max()
{
    if(a > b) return a;
    return b;
}