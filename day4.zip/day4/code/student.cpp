#include <iostream>
#include "student.h"


int student::count = 0;  // 静态属性必须在类外进行初始化，否则会出现未定义的语法错误


student::student()
{
}


student::student(int sno, string name):sno(sno), name(name)
{    
}


student::~student()
{
}


string student::getName() const
{
    return name;
}


void student::setName(const char* name)
{
    this->name = name;
}


void student::show() const
{
    cout << sno << ' ' << name << endl;
}


void student::f()
{
    count++;

    // 在静态方法中不能访问非静态成员
    // sno = 3;
    // show();

    cout << "我是一个静态方法！" << endl;
}

