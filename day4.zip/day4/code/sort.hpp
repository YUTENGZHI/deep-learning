

// 定义函数模板
template <typename T>
void sort(T* nums, int len)
{
    int i, j;

    for(i = 0; i < len - 1; i++)
    {
        for(j = 0; j < len - i - 1; j++)
        {
            if(nums[j] > nums[j + 1])
            {
                nums[j] = nums[j] + nums[j + 1];
                nums[j + 1] = nums[j] - nums[j + 1];
                nums[j] = nums[j] - nums[j + 1];
            }
        }
    }
}

