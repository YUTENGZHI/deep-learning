#include <iostream>
#include <ctime>
#include "opencv2/opencv.hpp"

using namespace std;
using namespace cv;


int main()
{
    VideoCapture camera(0);  // 定义一个 VideoCapture 类的对象，就是系统中默认摄像头（索引为 0）对象，如果想打开其他摄像头，就使用 1、2 等索引
    
    if(!camera.isOpened())
    {
        cerr << "摄像头打开失败！" << endl;
        return 1;
    }

    double fps, width, height;
    
    fps = camera.get(CAP_PROP_FPS);
    width = camera.get(CAP_PROP_FRAME_WIDTH);
    height = camera.get(CAP_PROP_FRAME_HEIGHT);

    // cout << fps << endl;
    // cout << width << endl;
    // cout << height << endl;

    VideoWriter vw("./test.mp4", VideoWriter::fourcc('m', 'p','4','v'), fps, Size(width, height));

    if(!vw.isOpened())
    {
        cerr << "打开视频文件(./test.mp4)失败！" << endl;
        return 1;
    }

    Mat img;  // 定义一个 Mat 对象（即矩阵），用于存放摄像头采集的一帧图像数据
    Mat watermark, result;
    int ret;
    int cnt = 0;

    watermark = imread("watermark.png");

    // time_t t1, t2;
    // time(&t1);

    while(1)
    {
        if(camera.read(img))  // 调用 camera 对象的 read 方法，从摄像头读取一帧图像并存放在 img 矩阵对象中
        {
            //line(img, Point(0, 0), Point(640, 480), Scalar(0, 0, 255), 10);  // 画一条红色的直线
            //line(img, Point(0, 480), Point(640, 0), Scalar(0, 255, 0), 10);  // 画一条绿色的直线

            // 画一个紫色的矩形
            //rectangle(img, Point(340, 40), Point(540, 140), Scalar(226, 43, 138), -1);

            // 画一个圆圈
            //circle(img, Point(320, 240), 200, Scalar(112, 25, 25), 5);

            // 输出文本内容
            //putText(img, "ITMOJUN yyds!", Point(20, 460), FONT_HERSHEY_SIMPLEX, 2.0, Scalar(0, 0, 255), 3);

            // for(int r = 0; r < img.rows; r++)
            // {
            //     for(int c = 0; c < img.cols; c++)
            //     {
            //         img.at<Vec3b>(r, c)[0] = 255 - img.at<Vec3b>(r, c)[0];  // 蓝色通道
            //         img.at<Vec3b>(r, c)[1] = 255 - img.at<Vec3b>(r, c)[1];  // 绿色通道
            //         img.at<Vec3b>(r, c)[2] = 255 - img.at<Vec3b>(r, c)[2];  // 红色通道
            //     }
            // }

            addWeighted(img, 0.7, watermark, 0.3, 0, result);  // 将两帧图像进行叠加(带权值)

            imshow("摄像头", result);  // 将 img 图像显示在名字为"摄像头"的窗口中

            if(cnt == 1)
            {
                vw << img;
            }
        }
        else
        {
            cerr << "读取摄像头失败！" << endl;
            break;
        }

        ret = waitKey(1);  // 等待 1 毫秒

        //cout << ret << endl;

        if(ret == 27) break;  // 当用户按下键盘上的 ESC 键时，waitKey 函数返回值为 27
        else if(ret == 's')
        {
            cnt++;

            if(cnt == 2) break;
        }
    }

    // time(&t2);
    // cout << t2 - t1 << endl;

    vw.release();
    camera.release();  // 释放摄像头    

    return 0;
}