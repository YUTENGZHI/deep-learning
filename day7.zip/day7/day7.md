# 嵌入式实训

## AI

人工智能(Artificial Intelligence，AI)：让机器像人类一样思考和决策。



AI 分支方向：

- 机器视觉

- 机器学习

- NLP

- 智能推荐

- 大模型

- ......

  

### 机器学习(Machine Learning)

ML 是当前实现 AI 的有效方式。



通过一个尽量庞大的数据集训练出一个特征模型，然后通过这个特征模型和新的事物进行匹配，通过相似程度进行决策。



#### 深度学习(Deep Learning)



AI > ML > DL

  