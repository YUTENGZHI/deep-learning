# 嵌入式实训

## OpenCV

### 让机器能够看到现实世界



使用 VideoCapture 类实现，支持从摄像头和视频文件逐帧捕获图像。





> FPS：Frames Per Second，帧率，即每秒刷新显示多少帧图像。



### 绘制简单图形和文字



line：画线