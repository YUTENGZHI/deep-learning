#include <iostream>
#include "opencv2/opencv.hpp"

using namespace std;
using namespace cv;


int main()
{
    Mat img = imread("/home/dengjun/code/test");

    if(img.empty())
    {
        cerr << "读取图片文件失败！" << endl;
        return 1;
    }

    Mat gray;
    cvtColor(img, gray, COLOR_BGR2GRAY);

    imwrite("gray.jpg", gray);

    imshow("junge", img);
    imshow("灰度图", gray);

    waitKey(0);

    return 0;
}



