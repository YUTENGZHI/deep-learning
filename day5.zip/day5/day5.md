# 嵌入式实训

## OpenCV



开源的计算机视觉(Computer Vision)开发库，本身是用 C++ 实现的，为多种语言提供了 API。



> 库(Library)：可以实现二进制级别代码复用，有共享库(.so)和静态库(.a)两种。



Halcon：工业领域常用的机器视觉库，闭源收费。



**搭建 OpenCV 开发环境**

1. 下载 OpenCV 库的源代码

   ```shell
   mkdir opencv && cd opencv
   
   git clone https://gitee.com/itmojun/opencv
   
   git clone https://gitee.com/itmojun/opencv_contrib  # OpenCV 扩展模块对应的项目
   ```

   

2. 安装 OpenCV 依赖的各种库

   ```shell
   sudo apt install -y g++ cmake make libgtk-3-dev libavcodec-dev libavformat-dev libswscale-dev
   ```



3. 将 cache.zip 文件解压到 OpenCV 项目文件夹下

   ```shell
   unzip cache.zip
   ```

   

3. 编译构建

   ```shell
   mkdir build && cd build
   
   cmake -DOPENCV_EXTRA_MODULES_PATH=../opencv_contrib/modules ../opencv  # 带上扩展模块一起编译构建
   
   make -j4  # -j4 表示使用 4 个线程同时执行构建任务，速度更快
   ```
   
   

> 如果 cmake 或 make 失败，直接删除整个 build 文件夹，然后再执行第 4 步即可。



**常用函数和类：**

- imread：读取一个图片文件，返回值为 Mat 对象。
- imshow：在某个窗口上显示一帧图像（即某个 Mat 对象），通过第一个参数指定目标窗口名，如果窗口不存在，就会创建一个新窗口。
- waitKey：等待用户在窗口上进行按键或鼠标操作，参数为超时时间，单位为毫秒，如果为 0 表示永不超时。返回值为用户按键的 编码值。
- Mat 类：矩阵类，存放一帧图像的所有像素点数据。



灰度图（单通道）

彩色图（多通道）

